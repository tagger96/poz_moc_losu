#!/bin/bash

python3 app_log_processor.py <receive_pipe.log
