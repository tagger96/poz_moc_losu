#!/bin/bash

./nc_receive_log_script.sh
