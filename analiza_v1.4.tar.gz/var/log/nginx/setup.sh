#!/bin/bash
mkfifo nginx_8k_all_access.log
