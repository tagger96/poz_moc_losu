#!/usr/bin/env python3
import os
import requests as rq
from subprocess import call

folder='/www-data/dynamic-cache'
while True:
	s=input()
	if(s==""):

		continue
	for the_file in os.listdir(folder):
		fp=os.path.join(folder,the_file)
		try:
			if os.path.isfile(fp):
				os.unlink(fp)
		except Exception as e:
			print(e)
		with open(folder+s,'w') as tmp:
			print(s)
			r=rq.get('http://127.0.0.1:8000'+s)
			tmp.write(r.text)
	call(["systemctl","reload","nginx.service"])
