#!/bin/bash

nc -l 23555 | ./app_log_processor.py| nc 127.0.0.1 23556
