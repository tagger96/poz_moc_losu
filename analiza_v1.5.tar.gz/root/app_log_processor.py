#!/usr/bin/env python3
from datetime import datetime,timedelta 
import threading
from time import sleep
import os
import requests as rq
import mysql.connector
user='test'
password='analiza2018'
sql_server='127.0.0.1'
database='ServersLogs'



log_list=[]
slownik={}
length=0
class Cleaner(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)
	def run(self):
		global length
		global slownik
		global log_list
		if not length:length=0
		while True:
			while(length>0 and abs(datetime.today()-log_list[0][0]).total_seconds()>300):
				if(slownik[log_list[0][1]][0]>1):	
					slownik[log_list[0][1]][0]-=1
				else:
					del slownik[log_list[0][1]]
				
				length-=1	
			sleep(1)
class AnalyzerThread(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)
		#self.folder='/www-data/dynamic-cache'
	def run(self):
		global slownik
		while True:
			top_vals=sorted(slownik.items(), key=lambda x:x[1][0], reverse=True)[0:10]
			if len(top_vals)>0:
				for i in top_vals:
					print(i[0])
			sleep(1)


cleaner = Cleaner()
cleaner.start()

analyzer= AnalyzerThread()
analyzer.start()

class MainLoop(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)
	def run(self):
		global slownik
		global log_list
		global length
		global user
		global password
		global sql_server
		global database
		cnx=mysql.connector.connect(user=user,password=password,host=sql_server,database=database,raise_on_warnings=False)
		while True:
			try:
				txt=(input().split('`````'))
			except EOFError:
				sleep(1)
				continue
			cursor=cnx.cursor()
			date=datetime.strptime(txt[0][:-6], '%d/%b/%Y:%H:%M:%S')
			request=txt[1].split()[1]
			cursor.execute("INSERT INTO Logs (logtime,request,server_addr,port) VALUES (%(logtime)s, %(request)s,%(server_addr)s,%(port)s)",{"logtime":date.isoformat(),"request":request,"server_addr":txt[3],"port":txt[2]})
			cnx.commit()
			if txt[1][:3]=="GET":
				log_list.append((date,request))
				try:
					slownik[log_list[-1][1]][0]+=1
					slownik[log_list[-1][1]][1]=txt[2]
				except KeyError:
					slownik[log_list[-1][1]]=[1,txt[2]]
				length+=1
		cnx.close()
main_loop=MainLoop()
main_loop.start()


cleaner.join()
