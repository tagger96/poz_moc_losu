#!/bin/bash

nc $1 23555 </var/log/nginx/nginx_8k_all_access.log
