#!/bin/bash

nc -l 23555 | /var/log/nginx/app_log_processor.py
