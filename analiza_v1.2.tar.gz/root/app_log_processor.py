#!/usr/bin/env python3
from datetime import datetime,timedelta 
import threading
from time import sleep
import os

log_list=[]
slownik={}
length=0
class Cleaner(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)
	def run(self):
		global length
		global slownik
		global log_list
		if not length:length=0
		while True:
			while(length>0 and abs(datetime.today()-log_list[0][0]).total_seconds()>300):
				if(slownik[log_list[0][1]][0]>1):	
					slownik[log_list[0][1]][0]-=1
				else:
					del slownik[log_list[0][1]]
				
				length-=1	
			sleep(1)
class AnalyzerThread(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)
		self.folder='/www-data/dynamic-cache'
	def run(self):
		global slownik
		while True:
			top_vals=sorted(slownik.items(), key=lambda x:x[1][0], reverse=True)[0:10]
			for the_file in os.listdir(self.folder):
				fp=os.path.join(self.folder,the_file)
				try:
					if os.path.isfile(file_path):
						os.unlink(file_path)
				except Exception as e:
					print(e)
			print(top_vals)
			sleep(1)


cleaner = Cleaner()
cleaner.start()

analyzer= AnalyzerThread()
analyzer.start()

class MainLoop(threading.Thread):
	def __init__(self):
		threading.Thread.__init__(self)
	def run(self):
		global slownik
		global log_list
		global length
		while True:
			try:
				txt=(input().split('`````'))
			except EOFError:
				sleep(1)
				continue
			if txt[1][:3]=="GET":
				log_list.append((datetime.strptime(txt[0][:-5], '%d/%b/%Y:%H:%M:%S '),txt[1].split()[1]),txt[2].split()[2])
				try:
					slownik[log_list[-1][1]][0]+=1
				except KeyError:
					slownik[log_list[-1][1]][0]=1
				length+=1
main_loop=MainLoop()
main_loop.start()


cleaner.join()
